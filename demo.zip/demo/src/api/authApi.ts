import axiosClient from "./axiosClient";
import type { AuthRequest, AuthResponse, RegisterRequest } from "../interfaces/auth";
import type { APIResponse } from "../interfaces/common";

const authApi = {
  login: (data: AuthRequest) => axiosClient.post<APIResponse<AuthResponse>>("/auth/login", data),
  register: (data: RegisterRequest) => axiosClient.post<APIResponse<AuthResponse>>("/auth/register", data),
};

export default authApi;
