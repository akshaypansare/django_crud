import { Link } from "react-router-dom";
import "./Navbar.css";
import logo from "../../assets/logo.png";
// import logo from "../../assets/logo2.png";

const Navbar = () => {
  return (
    <nav className="navbar">
      {/* --- Logo --- */}
      <div className="navbar-logo">
        <Link to="/">
          <img src={logo} alt="HealthCare Claims Logo" />
        </Link>
      </div>

      {/* --- Navigation Links --- */}
      <div className="navbar-links">
        <Link to="/">Home</Link>
        <Link to="/login">Login</Link>
        <Link to="/register">Register</Link>
      </div>
    </nav>
  );
};

export default Navbar;
