export interface AuthRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
}

export interface UserResponseDTO {
  userId: number;
  name: string;
  email: string;
  role: string; // RoleEnum in backend
  active: boolean;
  deleted: boolean;
}

export interface AuthResponse {
  token: string;
  user: UserResponseDTO;
}
