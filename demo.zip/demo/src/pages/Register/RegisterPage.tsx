import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import authApi from "../../api/authApi";
import logo from "../../assets/logo.png";
import { useAuth } from "../../context/AuthContext";
import type { AuthResponse, RegisterRequest } from "../../interfaces/auth";
import type { APIResponse } from "../../interfaces/common";
import "../../styles/auth.css";

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [formData, setFormData] = useState<RegisterRequest>({
    name: "",
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await authApi.register(formData);
      const apiResponse: APIResponse<AuthResponse> = response.data;

      if (apiResponse.status === "SUCCESS") {
        const { token, user } = apiResponse.data;
        login(token, user);
        navigate("/dashboard");
      } else {
        setError(apiResponse.message || "Registration failed");
      }
    } catch (err: any) {
      setError(err.response?.data?.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">

      <div className="auth-container">
        <div className="auth-card">
          <h2 className="auth-title">Create Account</h2>
          {error && <p className="auth-error">{error}</p>}

          <form onSubmit={handleSubmit} className="auth-form">
            <div>
              <label className="auth-label">Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="auth-input"
              />
            </div>

            <div>
              <label className="auth-label">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="auth-input"
              />
            </div>

            <div>
              <label className="auth-label">Password</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                className="auth-input"
              />
            </div>

            <button type="submit" disabled={loading} className="auth-button">
              {loading ? "Registering..." : "Register"}
            </button>
          </form>

          <p className="auth-link">
            Already have an account?{" "}
            <span onClick={() => navigate("/login")}>Login here</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
