import { useNavigate } from "react-router-dom";
import "./LandingPage.css";
import Navbar from "../../components/Navbar/Navbar";

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <>
      <Navbar />
      <section className="landing-container">
        {/* Left Section */}
        <div className="landing-content">
          <h1 className="landing-title">
            Simplify Your Health Insurance Claims
          </h1>
          <p className="landing-description">
            Manage, track, and claim your health insurance seamlessly with transparency and speed. 
            Empowering both users and admins to handle insurance claims effortlessly.
          </p>

          <div className="landing-buttons">
            <button className="primary" onClick={() => navigate("/login")}>
              Login
            </button>
            <button className="outline" onClick={() => navigate("/register")}>
              Register
            </button>
          </div>
        </div>

        {/* Right Section (Illustration) */}
        <div className="landing-image">
          <img
            src="https://cdn-icons-png.flaticon.com/512/4320/4320371.png"
            alt="Health Insurance Illustration"
          />
        </div>
      </section>
    </>
  );
};

export default LandingPage;
