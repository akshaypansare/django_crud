import { useAuth } from "../../context/AuthContext";

const DashboardPage = () => {
  const { logout } = useAuth();
  return (
    <div>
      <h2>Dashboard</h2>
      <button onClick={logout}>Logout</button>
    </div>
  );
};

export default DashboardPage;
